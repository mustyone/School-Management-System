<?php

get('/', 'views/landing/index');
get('/result', 'views/result/login');
get('/logout', 'controllers/logout');
get('/result/admin/dashboard', 'views/result/admin/dashboard');

get('/result/admin/schoolinfo', 'views/result/admin/schoolinfo');

get('/result/admin/newsession', 'views/result/admin/newacademicsession');
get('/result/admin/academicsessions', 'views/result/admin/academicsessions');
get('/result/admin/editsession/$id', 'views/result/admin/editsession');
get('/result/admin/deletesession/$id', 'views/result/admin/deletesession');
get('/result/admin/markactivesession/$id', 'views/result/admin/markactivesession');

get('/result/admin/newsection', 'views/result/admin/newsection');
get('/result/admin/allsections', 'views/result/admin/allsections');
get('/result/admin/editsection/$id', 'views/result/admin/editsection');
get('/result/admin/deletesection/$id', 'views/result/admin/deletesection');

get('/result/admin/newclass', 'views/result/admin/newclass');
get('/result/admin/allclasses', 'views/result/admin/allclasses');
get('/result/admin/editclass/$id', 'views/result/admin/editclass');
get('/result/admin/deleteclass/$id', 'views/result/admin/deleteclass');

get('/result/admin/newsubject', 'views/result/admin/newsubject');
get('/result/admin/allsubjects', 'views/result/admin/allsubjects');
get('/result/admin/editsubject/$id', 'views/result/admin/editsubject');
get('/result/admin/deletesubject/$id', 'views/result/admin/deletesubject');

get('/result/admin/grading', 'views/result/admin/grading');
get('/result/admin/grading/$section_id', 'views/result/admin/grading');

get("/result/admin/newassesment", 'views/result/admin/newassesment');
get("/result/admin/allassesments", 'views/result/admin/allassesments');
get('/result/admin/editassesment/$id', 'views/result/admin/editassesment');
get('/result/admin/deleteassesment/$id', 'views/result/admin/deleteassesment');


get('/result/admin/comments', 'views/result/admin/comments');
get('/result/admin/comments/$section_id', 'views/result/admin/comments');
get('/result/admin/deletecomment/$id', 'views/result/admin/deletecomment');

get('/result/admin/newstudent', 'views/result/admin/newstudent');
get('/result/admin/newbulkstudent', 'views/result/admin/newbulkstudent');
get('/result/admin/registerstudent', 'views/result/admin/registerstudent');
get('/result/admin/deleteregistration/$id', 'views/result/admin/deleteregistration');
get('/result/admin/students', 'views/result/admin/allstudents');
get('/result/admin/editstudent/$id', 'views/result/admin/editstudent');
get('/result/admin/deletestudent/$id', 'views/result/admin/deletestudent');
get('/result/admin/studentfile','views/result/admin/studentfile');

get('/result/admin/uploadreport','views/result/admin/uploadreport');
get('/result/admin/updatereport','views/result/admin/updatereport');
get('/result/admin/recordingsheet','/views/result/admin/recordingsheet');
get('/result/admin/studentreport','/views/result/admin/studentreport');


get('/result/admin/subjectbroadsheet', '/views/result/admin/subjectbroadsheet');


get('/result/admin/newteacher', '/views/result/admin/newteacher');
get('/result/admin/teachers', '/views/result/admin/allteachers');
get('/result/admin/editteacher/$id', 'views/result/admin/editteacher');
get('/result/admin/deleteteacher/$id', 'views/result/admin/deleteteacher');
get('/result/admin/blockteacher/$id', 'controllers/blockteacher');
get('/result/admin/unblockteacher/$id', 'controllers/unblockteacher');
get('/result/admin/assignsubjects', '/views/result/admin/assignsubjects');
get('/result/admin/assignclassteacher', '/views/result/admin/assignclassteacher');


get('/result/admin/preparepromotionlist', '/views/result/admin/preparepromotionlist');
get('/result/admin/promotionlist', '/views/result/admin/promotionlist');

get('/result/admin/newbackup', '/views/result/admin/backup');
get('/result/admin/backuprecords', '/views/result/admin/backuprecords');
get('/result/admin/deletebackup/$id', 'controllers/deletebackup');
get('/result/admin/restorebackup', '/views/result/admin/restorebackup');

get('/result/admin/upgradeapp', '/views/result/admin/upgradeapp');



//############## POST REQUESTS

post('/result/admin/backupdatabase','controllers/backupdatabase');
post('/result/admin/restorebackup','controllers/restorebackup');

post('/result/admin/showpromotionlist', 'controllers/showpromotionlist');
post('/result/admin/showpromotionlists', 'controllers/showpromotionlists');

post('/result/admin/savepromotionlist', 'controllers/savepromotionlist');


post('/result/admin/newteacher', 'controllers/addteacher');
post('/result/admin/updateteacher','controllers/updateteacher');
post('/result/admin/deleteteacher', 'controllers/deleteteacher');
post('/result/admin/showsubjectassignment', 'controllers/showsubjectassignment');
post('/result/admin/saveassignments', 'controllers/saveassignments');
post('/result/admin/showclassassignment', 'controllers/showclassassignment');
post('/result/admin/saveclassassignments', 'controllers/saveclassassignments');



post('/result/admin/fetchbroadsheet', 'controllers/fetchbroadsheet');


post('/result/admin/uploadreport','controllers/uploadreport');
post('/result/admin/updatereport','controllers/updatereport');
post('/result/admin/updateresult','controllers/updateresult');
post('/result/admin/saveresult','controllers/saveresult');
post('/result/admin/recordingsheet','controllers/recordingsheet');
post('/result/admin/fetchresult', 'controllers/fetchresult');

post('/result/admin/updatestudent', 'controllers/updatestudent');
post('/result/admin/deleteregistration', 'controllers/deleteregistration');
post('/result/admin/registerstudent', 'controllers/registerstudent');
post('/result/admin/newstudent', 'controllers/savestudent');
post('/result/admin/newbulkstudent', 'controllers/savestudents');
post('/result/admin/showstudents', 'controllers/showstudents');
post('/result/admin/filterstudents', 'controllers/filterstudents');
post('/result/admin/deletestudent', 'controllers/deletestudent');
post('/result/admin/showstudentfile', 'controllers/showstudentfile');



post('/result/admin/showcomments', 'controllers/showcomments');
post('/result/admin/updatecomments', 'controllers/updatecomments');
post('/result/admin/savecomments', 'controllers/savecomments');
post('/result/admin/deletecomment', 'controllers/deletecomment');


post('/result/admin/newassesment', 'controllers/savetest');
post('/result/admin/editassesment', 'controllers/updateassesment');
post('/result/admin/deleteassesment', 'controllers/deleteassesment');

post('/result/admin/showgrading', 'controllers/showgrading');
post('/result/admin/updategrading', 'controllers/updategrading');
post('/result/admin/savegrading', 'controllers/savegrading');



post('/result/admin/newsubject', 'controllers/savesubject');
post('/result/admin/editsubject', 'controllers/updatesubject');
post('/result/admin/deletesubject', 'controllers/deletesubject');

post('/result/admin/updateacademicsession', 'controllers/updateacademicsession');
post('/result/admin/deleteacademicsession', 'controllers/deleteacademicsession');
post('/result/admin/markactivesession', 'controllers/markactivesession');

post('/result/admin/newsection', 'controllers/savesection');
post('/result/admin/editsection', 'controllers/updatesection');
post('/result/admin/deletesection', 'controllers/deletesection');

post('/result/admin/newclass', 'controllers/saveclass');
post('/result/admin/editclass', 'controllers/updateclass');
post('/result/admin/deleteclass', 'controllers/deleteclass');





// Dynamic GET. Example with 1 variable
// The $id will be available in user.php
get('/user/$id', 'views/user');

// Dynamic GET. Example with 2 variables
// The $name will be available in full_name.php
// The $last_name will be available in full_name.php
// In the browser point to: localhost/user/X/Y
get('/user/$name/$last_name', 'views/full_name.php');

// Dynamic GET. Example with 2 variables with static
// In the URL -> http://localhost/product/shoes/color/blue
// The $type will be available in product.php
// The $color will be available in product.php
get('/product/$type/color/$color', 'product.php');

// A route with a callback
get('/callback', function(){
  echo 'Callback executed';
});

// A route with a callback passing a variable
// To run this route, in the browser type:
// http://localhost/user/A
get('/callback/$name', function($name){
  echo "Callback executed. The name is $name";
});

// A route with a callback passing 2 variables
// To run this route, in the browser type:
// http://localhost/callback/A/B
get('/callback/$name/$last_name', function($name, $last_name){
  echo "Callback executed. The full name is $name $last_name";
});

// ##################################################
// ##################################################
// ##################################################
// any can be used for GETs or POSTs

// For GET or POST
// The 404.php which is inside the views folder will be called
// The 404.php has access to $_GET and $_POST
any('/404','views/404.php');
