<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">

<title>Student Result Processing System - <?= APP_VERSION; ?>
</title>


<!-- Stylesheets -->
<link rel="stylesheet" id="css-main" href="<?= BASE_URL ?>/assets/css/oneui.min.css">

<!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
<!-- <link rel="stylesheet" id="css-theme" href="assets/css/themes/amethyst.min.css"> -->
<!-- END Stylesheets -->

<link rel="stylesheet" href="<?= BASE_URL ?>/assets/js/plugins/datatables-bs5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/js/plugins/datatables-buttons-bs5/css/buttons.bootstrap5.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/js/plugins/datatables-responsive-bs5/css/responsive.bootstrap5.min.css">