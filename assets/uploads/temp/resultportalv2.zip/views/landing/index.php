<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">

    <title>Student Result Processing System - <?= APP_VERSION; ?></title>


    <!-- Stylesheets -->
    <!-- OneUI framework -->
    <link rel="stylesheet" id="css-main" href="/assets/css/oneui.min.css">

    <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel="stylesheet" id="css-theme" href="assets/css/themes/amethyst.min.css"> -->
    <!-- END Stylesheets -->
</head>

<body>
    <div id="page-container">

        <!-- Main Container -->
        <main id="main-container">
            <!-- Page Content -->
            <div class="container mt-3">
                <div class="row justify-content-center push">
                    <div class="col-md-6">
                        <a href="result" style="color:#333">
                            <div class="card">
                                <div class="card-body text-center py-5">
                                    <i class="far fa-file-lines fa-7x"></i>
                                    <h2 class="card-title my-2">Result Module</h2>

                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="cbt" style="color:#333">
                            <div class="card">
                                <div class="card-body text-center py-5">
                                    <i class="fa fa-computer fa-7x"></i>
                                    <h2 class="card-title my-2">CBT Module</h2>

                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

        </main>
    </div>
</body>

